![Powered-taller-R-orange](https://img.shields.io/badge/Powered_by-Taller_R-blue?logo=R) ![GitHub](https://img.shields.io/github/license/taller-R/clase_11) [![contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat)](https://github.com/taller-R/clase_11/issues) ![](https://img.shields.io/github/followers/taller-R?style=social) 

<img src="https://avatars0.githubusercontent.com/u/69440432?s=400&u=96b3e58c713578b563d5c3d3c259f34965ac8e33&v=4" align="right" width=120 height=120 alt="" />

# Taller 2

Este repositorio contiene las instrucciones del Taller 2 del curso. Leer atentamente las instrucciones en Taller-02.pdf